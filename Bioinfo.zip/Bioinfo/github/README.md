## Projeto Bioinfo

Este é um projeto NetBeans. Se ainda não o tem instalado, acesse: [NetBeans 12.1](https://netbeans.apache.org/download/nb121/index.html).

### Configuração do Apache Tomcat

Este projeto utiliza o Apache Tomcat como container para rodar os servlets. Se ainda não o tem instalado, confira o tutorial: [Instalação do Apache Tomcat](https://youtu.be/WCQ6idDNiH0?si=v5OO_EIk5d0K3uF9).

### Importação do Projeto

Para importar o projeto no NetBeans:

1. Clique em **File -> Import Project -> From Zip**.
2. Selecione o arquivo `Bioinfo.zip` disponibilizado em `Bioinfo/github/`.

Se o projeto não aparecer diretamente, siga estes passos alternativos:

1. Clique em **File -> Open Project**.
2. Selecione o diretório onde está o projeto `Bioinfo`.

### Execoteando o Projeto

1. Clique em **play** e espere.

![Imagem exemplo](github/tut.png)
